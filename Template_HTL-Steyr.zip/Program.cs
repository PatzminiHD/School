﻿//*********************************************************************************************
//  Project:    $safeprojectname$
//  Namespace:  $safeprojectname$
//  Path:       E:\School\AIIT\5AHME\CSharp\
//  File:       Program.cs
// --------------------------------------------------------------------------------------------
//  Date:       $time$
//  Username:	$username$
//  Developer:  <PatzminiHD>
// --------------------------------------------------------------------------------------------
//  Machine:	$machinename$
//  System-OS:  WIN11-Enterprise
//  IDE:        MS Visual Studio Community 2022
// --------------------------------------------------------------------------------------------
//  
// --------------------------------------------------------------------------------------------
//  Description of Task:
//	
//              				
//				
// 
// --------------------------------------------------------------------------------------------
//  Date:                       Author:                     Reason for Change
//  $time$                      <PatzminiHD>                Creation of project ....
//*********************************************************************************************

// ----------------------------- using Directives to include different namespaces -------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//  -------------------------------------------- START -----------------------------------------

namespace $safeprojectname$
{
    class Program
    {
        // --------------------------------------------------------
        //	Hauptprogramm:   Main()
        // --------------------------------------------------------		

        static void Main(string[] args)
        {
        
        //	-----------------------------------------------
        //	Setups
        //	-----------------------------------------------
        Console.Title = "$safeprojectname$";
        Console.ForegroundColor = ConsoleColor.Green;

        //	-----------------------------------------------
        //	Definition of variables & data structures
        //	-----------------------------------------------
            



        //	-----------------------------------------------
        //	Instructions & Procedures
        //	-----------------------------------------------



        //	-----------------------------------------------
        //	Programm-Ende
        //	-----------------------------------------------
        Console.WriteLine("\n\n\tENTER => Programm-Ende\n\n");
        Console.Read();

        }   // --> end of main	


    }   // --> end of class


}   //  --> end of namespace

//  -------------------------------------------- END  -----------------------------------------
